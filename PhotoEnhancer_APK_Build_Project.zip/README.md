# Photo Enhancer Android APK project

This project builds a debug APK using GitHub Actions.

## Build from a phone using Chrome
1. Sign in to GitHub and create a new **public** repository named `PhotoEnhancer`.
2. In the repository, tap **Add file → Upload files** and upload the project files/folders from this ZIP. Make sure `.github/workflows/build-apk.yml` is included at exactly that path.
3. Commit the upload to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build Photo Enhancer APK** and tap **Run workflow** if it has not started automatically.
5. Wait for the run to show a green check. Open the run, scroll to **Artifacts**, and download `PhotoEnhancer-debug-apk`.
6. Extract the downloaded artifact ZIP and tap the `.apk` file to install. Android may ask you to allow Chrome or Files to install unknown apps; only enable this for the APK you just built, then turn it off again.

## Notes
- The app is non-generative and performs mild contrast/sharpening plus optional upscaling.
- It does not claim to restore details that are absent from the original.
- This is a debug APK for personal testing, not a Play Store release.
- Photos are processed locally on the phone; no photo upload server is included.
