package com.example.photoenhancer

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var photoView: ImageView
    private lateinit var statusText: TextView
    private lateinit var selectButton: Button
    private lateinit var enhanceButton: Button
    private lateinit var upscaleButton: Button
    private lateinit var saveButton: Button
    private var original: Bitmap? = null
    private var result: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        photoView = findViewById(R.id.photoView)
        statusText = findViewById(R.id.statusText)
        selectButton = findViewById(R.id.selectButton)
        enhanceButton = findViewById(R.id.enhanceButton)
        upscaleButton = findViewById(R.id.upscaleButton)
        saveButton = findViewById(R.id.saveButton)

        selectButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(intent, PICK_IMAGE)
        }
        enhanceButton.setOnClickListener { process(false) }
        upscaleButton.setOnClickListener { process(true) }
        saveButton.setOnClickListener { savePhoto() }
    }

    @Deprecated("Legacy picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream) ?: throw IOException("Unsupported image")
                    original = bmp.copy(Bitmap.Config.ARGB_8888, false)
                    result = null
                    photoView.setImageBitmap(original)
                    enhanceButton.isEnabled = true
                    upscaleButton.isEnabled = true
                    saveButton.isEnabled = false
                    statusText.text = "Loaded: ${bmp.width} × ${bmp.height}"
                }
            } catch (e: Exception) {
                statusText.text = "Could not open photo: ${e.message}"
            }
        }
    }

    private fun process(make4k: Boolean) {
        val source = original ?: return
        setBusy(true)
        statusText.text = "Processing…"
        Thread {
            try {
                val working = resizeLongEdge(source, 2000)
                val enhanced = gentleEnhance(working)
                val output = if (make4k) upscaleLongEdge(enhanced, 3840) else enhanced
                runOnUiThread {
                    result = output
                    photoView.setImageBitmap(output)
                    statusText.text = "Done: ${output.width} × ${output.height}. Check the result before saving."
                    saveButton.isEnabled = true
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Enhancement failed: ${e.message}"
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun setBusy(busy: Boolean) {
        selectButton.isEnabled = !busy
        enhanceButton.isEnabled = !busy && original != null
        upscaleButton.isEnabled = !busy && original != null
        saveButton.isEnabled = !busy && result != null
    }

    // Gentle contrast and mild unsharp mask; no face/body detection or generation.
    private fun gentleEnhance(input: Bitmap): Bitmap {
        val w = input.width
        val h = input.height
        val src = IntArray(w * h)
        input.getPixels(src, 0, w, 0, 0, w, h)
        val tonal = IntArray(src.size)
        for (i in src.indices) {
            val c = src[i]
            fun adjust(v: Int) = ((v - 128) * 1.045f + 129f).roundToInt().coerceIn(0, 255)
            tonal[i] = Color.argb(Color.alpha(c), adjust(Color.red(c)), adjust(Color.green(c)), adjust(Color.blue(c)))
        }
        val out = tonal.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val p = y * w + x
                val c = tonal[p]
                val up = tonal[p - w]; val dn = tonal[p + w]
                val lf = tonal[p - 1]; val rt = tonal[p + 1]
                fun sharp(v: Int, a: Int, b: Int, d: Int, e: Int): Int {
                    val avg = (a + b + d + e) / 4
                    return (v + (v - avg) * 0.25f).roundToInt().coerceIn(0, 255)
                }
                out[p] = Color.rgb(
                    sharp(Color.red(c), Color.red(up), Color.red(dn), Color.red(lf), Color.red(rt)),
                    sharp(Color.green(c), Color.green(up), Color.green(dn), Color.green(lf), Color.green(rt)),
                    sharp(Color.blue(c), Color.blue(up), Color.blue(dn), Color.blue(lf), Color.blue(rt))
                )
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun resizeLongEdge(b: Bitmap, edge: Int): Bitmap {
        val longest = max(b.width, b.height)
        if (longest <= edge) return b
        val ratio = edge.toFloat() / longest
        return Bitmap.createScaledBitmap(b, (b.width * ratio).roundToInt(), (b.height * ratio).roundToInt(), true)
    }

    private fun upscaleLongEdge(b: Bitmap, edge: Int): Bitmap {
        val ratio = edge.toFloat() / max(b.width, b.height)
        return Bitmap.createScaledBitmap(b, (b.width * ratio).roundToInt(), (b.height * ratio).roundToInt(), true)
    }

    private fun savePhoto() {
        val bmp = result ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Enhanced_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoEnhancer")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: run {
            Toast.makeText(this, "Could not save image", Toast.LENGTH_LONG).show()
            return
        }
        try {
            contentResolver.openOutputStream(uri).use { stream ->
                if (stream == null || !bmp.compress(Bitmap.CompressFormat.JPEG, 96, stream)) {
                    throw IOException("Could not write image")
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            }
            statusText.text = "Saved in Pictures/PhotoEnhancer"
            Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            statusText.text = "Save failed: ${e.message}"
        }
    }

    companion object { private const val PICK_IMAGE = 4102 }
}
